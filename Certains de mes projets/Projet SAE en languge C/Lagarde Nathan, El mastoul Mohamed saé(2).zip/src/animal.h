#pragma once
#ifndef ANIMAL_H
#define ANIMAL_H

#define MAX_NOM 20

typedef struct {
    char nom[MAX_NOM];
} Animal;

#endif