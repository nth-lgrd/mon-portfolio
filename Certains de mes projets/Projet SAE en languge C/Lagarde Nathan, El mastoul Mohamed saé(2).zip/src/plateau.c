#include "partie.h"
#pragma warning(disable : 4996 6031 6054)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>


int chargerConfig(Jeu* jeu, const char* fichier) {
    FILE* f = fopen(fichier, "r");
    if (!f) return 0;

    
    char buffer[256];
    if (fgets(buffer, sizeof(buffer), f)) {
        buffer[strcspn(buffer, "\n")] = 0;
        char* token = strtok(buffer, " ");
        jeu->nbAnimaux = 0;
        while (token && jeu->nbAnimaux < MAX_ANIMAUX) {
            strncpy(jeu->animaux[jeu->nbAnimaux].nom, token, MAX_NOM);
            jeu->nbAnimaux++;
            token = strtok(NULL, " ");
        }
    }

    
    if (fgets(buffer, sizeof(buffer), f)) {
        buffer[strcspn(buffer, "\n")] = 0;
        char* token = strtok(buffer, " ");
        jeu->nbCommandes = 0;
        while (token && jeu->nbCommandes < MAX_CMDS) {
            strncpy(jeu->commandes[jeu->nbCommandes], token, 3);
            jeu->nbCommandes++;
            token = strtok(NULL, " ");
        }
    }
    fclose(f);

    if (jeu->nbAnimaux < 2 || jeu->nbCommandes < 3) return 0; 
    return 1;
}

void ajouterJoueur(Jeu* jeu, const char* nom) {
    if (jeu->nbJoueurs < MAX_JOUEURS) {
        strncpy(jeu->joueurs[jeu->nbJoueurs].nom, nom, MAX_NOM);
        jeu->joueurs[jeu->nbJoueurs].score = 0;
        jeu->joueurs[jeu->nbJoueurs].elimine = false;
        jeu->nbJoueurs++;
    }
}

// G�n�re un plateau al�atoire valide
void genererPlateauAleatoire(Plateau* p, int nbAnimaux) {
    initPlateau(p, nbAnimaux);
    int coups = 10 + rand() % 20;
    for (int i = 0; i < coups; ++i) {
        int r = rand() % 5;
        switch (r) {
        case 0: actionKI(p); break;
        case 1: actionLO(p); break;
        case 2: actionSO(p); break;
        case 3: actionNI(p); break;
        case 4: actionMA(p); break;
        }
    }
}

// V�rifie si une chaine ne contient que des commandes valides
bool verifierSyntaxe(const char* seq, const char cmds[][3], int nbCmds) {
    int len = strlen(seq);
    if (len % 2 != 0) return false;

    for (int i = 0; i < len; i += 2) {
        char sub[3] = { seq[i], seq[i + 1], '\0' };
        bool trouve = false;
        for (int j = 0; j < nbCmds; ++j) {
            if (strcmp(sub, cmds[j]) == 0) {
                trouve = true;
                break;
            }
        }
        if (!trouve) return false;
    }
    return true;
}

// Trie les joueurs pour le score final 
void afficherScores(Jeu* jeu) {
    for (int i = 0; i < jeu->nbJoueurs - 1; ++i) {
        for (int j = 0; j < jeu->nbJoueurs - i - 1; ++j) {
            if (jeu->joueurs[j].score < jeu->joueurs[j + 1].score) {
                Joueur temp = jeu->joueurs[j];
                jeu->joueurs[j] = jeu->joueurs[j + 1];
                jeu->joueurs[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < jeu->nbJoueurs; ++i) {
        printf("%s %d\n", jeu->joueurs[i].nom, jeu->joueurs[i].score);
    }
}

void lancerPartie(Jeu* jeu) {
    srand(time(NULL));

    // Affichage initial des r�gles 
    printf("KI (B->R) | LO (B<-R) | SO (B<->R) | NI (B^) | MA (R^)\n\n");

    Plateau depart, arrivee;
    initPlateau(&depart, jeu->nbAnimaux); 
    genererPlateauAleatoire(&depart, jeu->nbAnimaux);

    
    for (int tour = 0; tour < 5; ++tour) {

        // Nouvelle arriv�e
        genererPlateauAleatoire(&arrivee, jeu->nbAnimaux);
        while (estEgal(&depart, &arrivee)) genererPlateauAleatoire(&arrivee, jeu->nbAnimaux);

        // R�init �tat joueurs
        for (int i = 0; i < jeu->nbJoueurs; i++) jeu->joueurs[i].elimine = false;
        int joueursRestants = jeu->nbJoueurs;

        bool tourGagne = false;
        afficherPlateauDouble(&depart, &arrivee, jeu->animaux, jeu->nbAnimaux);

        while (!tourGagne && joueursRestants > 0) {
            char saisieNom[MAX_NOM];
            char saisieSeq[100];

            
            if (scanf("%s", saisieNom) == EOF) return;

            // V�rifier si le joueur existe
            int idJoueur = -1;
            for (int i = 0; i < jeu->nbJoueurs; i++) {
                if (strcmp(jeu->joueurs[i].nom, saisieNom) == 0) idJoueur = i;
            }

            if (idJoueur == -1) {
                scanf("%*[^\n]");
                continue;
            }

           
            scanf("%s", saisieSeq);

            
            if (jeu->joueurs[idJoueur].elimine) {
                printf("%s ne peut plus jouer durant ce tour\n", saisieNom);
                continue;
            }

            
            if (!verifierSyntaxe(saisieSeq, jeu->commandes, jeu->nbCommandes)) {
                printf("L'ordre contient des commandes inconnues\n");
                jeu->joueurs[idJoueur].elimine = true;
                joueursRestants--;
            }
            else {
                Plateau test = depart;
                executerOrdre(&test, saisieSeq, NULL);

                if (estEgal(&test, &arrivee)) {
                    printf("%s gagne un point\n\n", saisieNom);
                    jeu->joueurs[idJoueur].score++;
                    tourGagne = true;
                    depart = arrivee; 
                }
                else {
                    printf("La sequence ne conduit pas a la situation attendue\n");
                    jeu->joueurs[idJoueur].elimine = true;
                    joueursRestants--;
                }
            }

            // Cas o� tout le monde a perdu sauf un 
            if (!tourGagne && joueursRestants == 1) {
                for (int i = 0; i < jeu->nbJoueurs; i++) {
                    if (!jeu->joueurs[i].elimine) {
                        printf("%s gagne un point car lui seul peut encore jouer durant ce tour\n\n", jeu->joueurs[i].nom);
                        jeu->joueurs[i].score++;
                        tourGagne = true;
                        depart = arrivee;
                    }
                }
            }

            if (!tourGagne && joueursRestants == 0) {
                printf("Personne n'a trouve. Tour suivant.\n\n");
                tourGagne = true;
                depart = arrivee;
            }
        }
    }

    afficherScores(jeu);
}