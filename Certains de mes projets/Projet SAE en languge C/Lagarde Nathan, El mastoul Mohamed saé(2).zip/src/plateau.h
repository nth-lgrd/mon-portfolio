#pragma once
#ifndef PLATEAU_H
#define PLATEAU_H

#include <stdio.h>
#include <stdbool.h>

// D�finitions constantes
#define MAX_ANIMAUX 5
#define MAX_NOM 20

// Structure pour un animal
typedef struct {
    char nom[MAX_NOM];
} Animal;


typedef struct {
    int animaux[MAX_ANIMAUX]; 
    int nb;                   
} Podium;


typedef struct {
    Podium bleu;
    Podium rouge;
} Plateau;

// Prototypes
void initPlateau(Plateau* p, int nbTotalAnimaux);
void executerOrdre(Plateau* p, const char* ordre, const char* commandesRef);
bool estEgal(const Plateau* p1, const Plateau* p2);
void afficherPlateauDouble(const Plateau* depart, const Plateau* arrivee, const Animal* dictionnaire, int nbAnimaux);

// Les 5 ordres de base
void actionKI(Plateau* p);
void actionLO(Plateau* p);
void actionSO(Plateau* p);
void actionNI(Plateau* p);
void actionMA(Plateau* p);

#endif
