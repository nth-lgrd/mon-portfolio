#include "plateau.h"
#include <string.h>
#include <stdlib.h>
#include <assert.h>


void initPlateau(Plateau* p, int nbTotalAnimaux) {
    p->bleu.nb = nbTotalAnimaux;
    p->rouge.nb = 0;
    for (int i = 0; i < nbTotalAnimaux; ++i) {
        p->bleu.animaux[i] = i; // 0 est en bas et nb-1 en haut
    }
}


void actionKI(Plateau* p) {
    if (p->bleu.nb > 0) {
        int animal = p->bleu.animaux[p->bleu.nb - 1];
        p->bleu.nb--;
        p->rouge.animaux[p->rouge.nb] = animal;
        p->rouge.nb++;
    }
}


void actionLO(Plateau* p) {
    if (p->rouge.nb > 0) {
        int animal = p->rouge.animaux[p->rouge.nb - 1];
        p->rouge.nb--;
        p->bleu.animaux[p->bleu.nb] = animal;
        p->bleu.nb++;
    }
}


void actionSO(Plateau* p) {
    if (p->bleu.nb > 0 && p->rouge.nb > 0) {
        int tmp = p->bleu.animaux[p->bleu.nb - 1];
        p->bleu.animaux[p->bleu.nb - 1] = p->rouge.animaux[p->rouge.nb - 1];
        p->rouge.animaux[p->rouge.nb - 1] = tmp;
    }
}


void actionNI(Plateau* p) {
    if (p->bleu.nb > 1) {
        int tmp = p->bleu.animaux[0]; 
        for (int i = 0; i < p->bleu.nb - 1; ++i) {
            p->bleu.animaux[i] = p->bleu.animaux[i + 1];
        }
        p->bleu.animaux[p->bleu.nb - 1] = tmp;
    }
}


void actionMA(Plateau* p) {
    if (p->rouge.nb > 1) {
        int tmp = p->rouge.animaux[0];
        for (int i = 0; i < p->rouge.nb - 1; ++i) {
            p->rouge.animaux[i] = p->rouge.animaux[i + 1];
        }
        p->rouge.animaux[p->rouge.nb - 1] = tmp;
    }
}

// Compare deux plateaux
bool estEgal(const Plateau* p1, const Plateau* p2) {
    if (p1->bleu.nb != p2->bleu.nb || p1->rouge.nb != p2->rouge.nb) return false;
    for (int i = 0; i < p1->bleu.nb; ++i)
        if (p1->bleu.animaux[i] != p2->bleu.animaux[i]) return false;
    for (int i = 0; i < p1->rouge.nb; ++i)
        if (p1->rouge.animaux[i] != p2->rouge.animaux[i]) return false;
    return true;
}

// Ex�cute une s�quence
void executerOrdre(Plateau* p, const char* ordre, const char* refs) {
    char cmd[3] = { 0 };
    int len = strlen(ordre);

    // On suppose que l'ordre est valid� avant et on ex�cute b�tement
    for (int i = 0; i < len; i += 2) {
        cmd[0] = ordre[i];
        cmd[1] = ordre[i + 1];
        if (strncmp(cmd, "KI", 2) == 0) actionKI(p);
        else if (strncmp(cmd, "LO", 2) == 0) actionLO(p);
        else if (strncmp(cmd, "SO", 2) == 0) actionSO(p);
        else if (strncmp(cmd, "NI", 2) == 0) actionNI(p);
        else if (strncmp(cmd, "MA", 2) == 0) actionMA(p);
    }
}


void afficherPlateauDouble(const Plateau* d, const Plateau* a, const Animal* dico, int nbAnimaux) {
    int hMax = nbAnimaux; 

    for (int i = hMax - 1; i >= 0; --i) {
        if (i < d->bleu.nb) printf("%-10s", dico[d->bleu.animaux[i]].nom);
        else printf("          "); // 10 espaces

        // Rouge
        if (i < d->rouge.nb) printf(" %-10s", dico[d->rouge.animaux[i]].nom);
        else printf("           ");

        //S�parateur
        if (i == 0) printf("  ==>  ");
        else        printf("       ");

    
        // Bleu
        if (i < a->bleu.nb) printf("%-10s", dico[a->bleu.animaux[i]].nom);
        else printf("          ");

        // Rouge
        if (i < a->rouge.nb) printf(" %-10s", dico[a->rouge.animaux[i]].nom);
        else printf("           "); // 10 espaces

        printf("\n");
    }

    // Bas des podiums
    printf("----       ----        ==>  ----       ----\n");
    printf("BLEU       ROUGE            BLEU       ROUGE\n\n");
}