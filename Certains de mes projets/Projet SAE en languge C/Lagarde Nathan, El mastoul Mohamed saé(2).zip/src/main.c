#include "partie.h"
#include <stdio.h>

int main(int argc, char* argv[]) {
    // V�rification des arguments
    if (argc < 3) {
        printf("Erreur : Il faut au moins 2 joueurs.\n");
        return 1;
    }

    Jeu monJeu;
    if (!chargerConfig(&monJeu, "crazy.cfg")) {
        printf("Erreur de lecture de crazy.cfg ou format invalide.\n");
        return 1;
    }

    // Ajout des joueurs depuis la ligne de commande 
    monJeu.nbJoueurs = 0;
    for (int i = 1; i < argc; ++i) {
        ajouterJoueur(&monJeu, argv[i]);
    }

    // Lancer la partie
    lancerPartie(&monJeu);

    return 0;
}