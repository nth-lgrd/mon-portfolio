#pragma once
#ifndef PARTIE_H
#define PARTIE_H

#include "plateau.h"

#define MAX_JOUEURS 10
#define MAX_CMDS 20

typedef struct {
    char nom[MAX_NOM];
    int score;
    bool elimine; // Si le joueur a fait une erreur dans le tour
} Joueur;

typedef struct {
    Animal animaux[MAX_ANIMAUX];
    int nbAnimaux;
    char commandes[MAX_CMDS][3]; 
    int nbCommandes;

    Joueur joueurs[MAX_JOUEURS];
    int nbJoueurs;
} Jeu;

int chargerConfig(Jeu* jeu, const char* fichier);
void ajouterJoueur(Jeu* jeu, const char* nom);
void lancerPartie(Jeu* jeu);

#endif
